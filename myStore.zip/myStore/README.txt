Please import the project in a suitable IDE

Run the testng.xml file to execute the tests

There are 4 tests :
1>validateSignUp() - Validates the mandatory fields
2>signUpTest() - Creates a new user
3>logInTest() - Logs in with an exisiting user
4>addToCartTest() - Validates an item after adding to the cart

Note : Please make signUpTest() false when running for the 2nd time , as this user gets created and used in the subsequent tests.

